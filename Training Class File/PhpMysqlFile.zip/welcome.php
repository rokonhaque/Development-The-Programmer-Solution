<html>
<head>
<title>
    Welcome to Php
</title>
</head>
<body>

<?php

$name = $_POST["stdname"];
$email = $_POST["email"];
$phone = $_POST["phone"];
$password = $_POST["pass"];

echo "Welcome " . $_POST["stdname"];

$insert = "insert into customer(name,email,password,phone) values ('$name','$email','$password','$phone')";


$con = mysqli_connect("mofiz.db.10483764.hostedresource.com", "mofiz", "Mafiz123@", "mofiz");
if($con)
{
    echo "Database connected";
    $result = mysqli_query($con,$insert);
    if($result)
    {
        echo "Registration Successfull";
    }
    else
    {
        echo "Mofiz failed";
    }
    
}
else
{
    
    echo "Mofiz out of service";
}



?>
</body>
</html>